import React, { useRef, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import SphereImg from "./Sphere";
import SphereLoad from "./SphereLoad";
import { Controls } from "./Controls";

const SphereImage = ({ imageUrl }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        width: "100vw"
      }}
    >
      <Canvas camera={{ position: [0, 0, 2] }}>
        <OrbitControls
          enableDamping={true}
          dampingFactor={0.25}
          maxDistance={2}
          minDistance={0.5}
          rotateSpeed={-0.25}
          zoomSpeed={1}
          enablePan
          enableZoom
        />
        {/* <SphereImg imageUrl={imageUrl} /> */}
        <SphereLoad url={imageUrl} radius={2.8} transparent={false} />
        {/* <Controls /> */}
      </Canvas>
    </div>
  );
};

export default SphereImage;
