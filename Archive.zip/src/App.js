import React, { useState } from "react";
import SphereImage from "./SphereImage";
import "./App.css";

const App = () => {
  const [imageUrl, setImageUrl] = useState("");

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      setImageUrl(reader.result);
    };
  };

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        flexDirection: "column",
        alignItems: "center"
      }}
    >
      <div
        className="pt-[50px]"
        style={{
          padding: "4px",
          width: "70vw",
          border: "1px solid black",
          borderRadius: "8px",
          margin: "8px 0"
        }}
      >
        <input
          type="file"
          className="custom-file-input w-full"
          onChange={handleFileChange}
          accept="image/*"
        />
      </div>
      {imageUrl && <SphereImage imageUrl={imageUrl} />}
    </div>
  );
};

export default App;
